# Fore Sight

A Pen created on CodePen.io. Original URL: [https://codepen.io/Arejetobi-Miracle/pen/MWMQZKJ](https://codepen.io/Arejetobi-Miracle/pen/MWMQZKJ).

